<?php
include('db_connect.php'); // Include database connection

$search = "";
$query = "SELECT * FROM trace_data ORDER BY id DESC";

if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    $query = "SELECT * FROM trace_data 
              WHERE contact LIKE '%$search%' 
                 OR group_name LIKE '%$search%' 
              ORDER BY id DESC";
}


$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Groups</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #121212; color: white; }
        .content { margin-left: 260px; padding: 20px; }
        .table-dark th, .table-dark td { color: white; }
    </style>
</head>
<body>
    <div class="content">
        <h2>Manage Groups - Tracking Data</h2>

        <!-- Search Form -->
        <form method="GET" class="mb-3">
            <input type="text" name="search" class="form-control w-25 d-inline" placeholder="Search by Email or Phone" value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </form>

        <table class="table table-dark table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Group Name</th>
                    <th>Email/Phone</th>
                    <th>OS</th>
                    <th>Device</th>
                    <th>User Agent</th>
                    <th>IP Address</th>
                    <th>Timestamp</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['group_name']) ?></td>
                        <td><?= htmlspecialchars($row['contact']) ?></td>
                        <td><?= htmlspecialchars($row['os']) ?></td>
                        <td><?= htmlspecialchars($row['device']) ?></td>
                        <td><?= htmlspecialchars($row['agent']) ?></td>
                        <td><?= htmlspecialchars($row['ip_address']) ?></td>
                        <td><?= $row['clicked_at'] ?></td>
                        <td>
                            <a href="delete_record.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm"
                               onclick="return confirm('Are you sure you want to delete this record?');">
                               Delete
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
