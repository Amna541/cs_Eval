<?php
include 'db_connect.php';

// Fetch total count of entries
$totalQuery = "SELECT COUNT(*) as total FROM trace_data";
$totalResult = $conn->query($totalQuery);
$totalClicks = $totalResult->fetch_assoc()['total'];

// Fetch count grouped by group_name
$groupQuery = "SELECT group_name, COUNT(*) as count FROM trace_data GROUP BY group_name";
$groupResult = $conn->query($groupQuery);
$groupCounts = [];
while ($row = $groupResult->fetch_assoc()) {
    $groupCounts[$row['group_name']] = $row['count'];
}

// Fetch count grouped by url
$urlQuery = "SELECT url, COUNT(*) as count FROM trace_data GROUP BY url";
$urlResult = $conn->query($urlQuery);
$urlCounts = [];
while ($row = $urlResult->fetch_assoc()) {
    $urlCounts[$row['url']] = $row['count'];
}

// Fetch count of URLs within each group_name
$groupedUrlQuery = "SELECT group_name, url, COUNT(*) as count FROM trace_data GROUP BY group_name, url";
$groupedUrlResult = $conn->query($groupedUrlQuery);
$groupedUrlCounts = [];
while ($row = $groupedUrlResult->fetch_assoc()) {
    $groupedUrlCounts[$row['group_name']][$row['url']] = $row['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    
    <title>Admin Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
    /* General Reset */
    body {
        font-family: 'Roboto', sans-serif;
        background: linear-gradient(135deg, #2c3e50, #4ca1af); /* Gradient background */
        color: #ffffff;
        line-height: 1.6;
        background-size: cover;
        background-attachment: fixed;
    }

    /* Hero Section */
    .hero-section {
        background: linear-gradient(45deg, #4ca1af, #2c3e50);
        padding: 80px 0;
        text-align: center;
        color: #ffffff;
    }

    .hero-content h1 {
        font-size: 48px;
        margin-bottom: 15px;
        font-weight: bold;
        font-family: 'Roboto', sans-serif;
    }

    .hero-content p {
        font-size: 20px;
        font-family: 'Roboto', sans-serif;
    }

    /* Sidebar */
    .sidebar {
        width: 250px;
        background-color: #222222;
        color: #ffffff;
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        padding-top: 20px;
        transition: all 0.3s ease;
        box-shadow: 2px 0px 10px rgba(0, 0, 0, 0.5);
    }

    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        color: #4DB6AC; /* Soft cyan */
    }

    .sidebar a {
        display: block;
        color: #b0bec5; /* Soft greyish-blue */
        text-decoration: none;
        padding: 15px;
        margin: 10px 0;
        border-radius: 5px;
        font-size: 18px;
        transition: background-color 0.3s ease, color 0.3s ease;
        display: flex;
        align-items: center;
    }

    .sidebar a i {
        margin-right: 10px;
    }

    .sidebar a:hover {
        background-color: #26A69A; /* Vibrant teal */
        color: #ffffff;
    }

    .sidebar a.active {
        background-color: #00897B; /* Deep cyan */
        color: #ffffff;
    }

    /* Content Area */
    .content {
        margin-left: 250px;
        padding: 20px;
        max-width: 90%;
        margin-top: 20px;
    }

    .content h2 {
        font-size: 32px;
        margin-bottom: 20px;
        font-weight: bold;
        color: #F1F8E9; /* Soft off-white */
    }

    /* Cards */
    .card {
        background: #263238; /* Dark blue-grey */
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        padding: 25px;
        margin-bottom: 30px;
        text-align: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        margin-top: 20px
    }

    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 12px rgba(0, 0, 0, 0.3);
    }

    .card h3 {
        font-size: 24px;
        margin-bottom: 15px;
        color: #80CBC4; /* Soft cyan */
    }

    .card p {
        font-size: 18px;
        color: #B0BEC5; /* Light greyish-blue */
    }

    /* Chart Styling */
    canvas {
        width: 100% !important;
        height: 400px !important;
    }
    /* Splash Screen */
/* Full-screen splash overlay */
#splash-screen {
    position: fixed;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5); /* Dark overlay */
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    transition: opacity 1s ease-in-out;
}

/* Blurred effect for dashboard */
#main-dashboard {
    filter: blur(10px);
    transition: filter 1s ease-in-out;
}

/* Center the splash image */
/* Full-screen splash overlay */
#splash-screen {
    position: fixed;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6); /* Dark overlay */
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    z-index: 9999;
    transition: opacity 1s ease-in-out;
}

/* Center the splash content */
.splash-content {
    text-align: center;
}

/* Logo image */
.splash-content img {
    width: 300px; /* Adjust size as needed */
    height: auto;
    animation: fadeIn 1s ease-in-out;
}

/* Splash text */
.splash-content h1 {
    color: red;
    font-size: 40px;
    margin-top: 15px;
    font-weight: bold;
    animation: fadeIn 1s ease-in-out;
}

/* Blurred effect for dashboard */
#main-dashboard {
    filter: blur(10px);
    transition: filter 1s ease-in-out;
}
.search-bar {
        width: 40%;
        padding: 12px 15px;
        font-size: 16px;
        border: 2px solid #4ca1af;
        border-radius: 25px;
        outline: none;
        transition: 0.3s;
        background-color: rgba(255, 255, 255, 0.2);
        color: #ffffff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .search-bar::placeholder {
        color: rgba(255, 255, 255, 0.7);
    }

    .search-bar:focus {
        border-color: #ffffff;
        background-color: rgba(255, 255, 255, 0.3);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    }
   /* Styling for the search bar container */
.search-container {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: 10px; /* Space between icon and input */
    background:  #263238; /* White background */
    border-radius: 8px;
    padding: 10px 15px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); /* Soft shadow for modern look */
    width: 100%;
    max-width: 400px; /* Keep it reasonably sized */
    margin-left:     400px;
}

/* Search Input Styling */
#groupSearch {
    flex: 1;
    border: none;
    outline: none;
    font-size: 16px;
    padding: 8px;
    background: transparent;
    color: #F1F8E9;
}

/* Search Icon Styling */
.search-icon {
    font-size: 18px;
    color: #888;
}

/* Styling for the 'Clicks by Group Name' Container */
.card-container {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    margin-top: 20px;
}

/* Fade-in animation */
@keyframes fadeIn {
    0% { opacity: 0; transform: scale(0.8); }
    100% { opacity: 1; transform: scale(1); }
}



</style>

</head>


<body>





<div class="sidebar">
    <h2>Admin Dashboard</h2>
    <a href="#" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="index.php"><i class="fas fa-users"></i> Group Dashboard</a>
    <a href="manage_groups.php"><i class="fas fa-cogs"></i> Manage Groups</a>
    <a href="tracking_data.php"><i class="fas fa-chart-line"></i> Tracking Data</a>
</div>





    <!-- Content Area -->
     
    <div class="content">
        <div class="card">
            <h3>Total Clicks</h3>
            <p><?php echo $totalClicks; ?></p>
        </div>
        
<!-- search bar -->
<div class="search-container">
    <i class="search-icon fas fa-search"></i> <!-- Font Awesome Icon -->
    <input type="text" id="groupSearch" placeholder="Search by Group Name" onkeyup="filterCharts()">
</div>




        <div class="card">
            <h3>Clicks by Group Name</h3>
            <div class="chart-container">
                <canvas id="pieChart"></canvas>
            </div>
            <div class="chart-container">
                <canvas id="urlBarChart"></canvas>
            </div>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>

        <?php foreach ($groupedUrlCounts as $group => $data) { ?>
    <div class="card group-chart" data-group="<?= strtolower($group); ?>">
        <h3><?= $group; ?> - URL Counts</h3>
        <div class="chart-container">
            <canvas id="chart_<?= $group; ?>"></canvas>
        </div>
    </div>
<?php } ?>
<script>
function filterCharts() {
    let searchQuery = document.getElementById("groupSearch").value.toLowerCase();
    let charts = document.querySelectorAll(".group-chart");

    charts.forEach(chart => {
        let groupName = chart.getAttribute("data-group");
        if (groupName.includes(searchQuery)) {
            chart.style.display = "block";  // Show matching groups
        } else {
            chart.style.display = "none";   // Hide non-matching groups
        }
    });
}
</script>


    </div>

    <script>
        const groupCounts = <?php echo json_encode($groupCounts); ?>;
        const totalClicks = <?php echo $totalClicks; ?>;
        const groupLabels = Object.keys(groupCounts);
        const groupValues = Object.values(groupCounts);

        // Convert to percentage for display
        const percentageValues = groupValues.map(count => ((count / totalClicks) * 100).toFixed(2));

        const pieChartCtx = document.getElementById('pieChart').getContext('2d');
new Chart(pieChartCtx, {
    type: 'pie',
    data: {
        labels: groupLabels.map((label, index) => `${label} (${percentageValues[index]}%)`),
        datasets: [{
            data: percentageValues,
            backgroundColor: ['#1ABC9C', '#3498DB', '#F39C12', '#9B59B6', '#E74C3C', '#2ECC71'],
            hoverOffset: 5
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    color: '#EAEAEA', // Light text for better visibility
                    font: {
                        size: 14
                    }
                }
            },
            tooltip: {
                titleColor: '#FFF',
                bodyColor: '#FFF',
                backgroundColor: '#333', // Darker background for tooltips
                callbacks: {
                    label: function(tooltipItem) {
                        const index = tooltipItem.dataIndex;
                        return `${groupLabels[index]}: ${groupValues[index]} clicks`;
                    }
                }
            }
        }
    }
});
    </script>

    <script>
        const urlCounts = <?php echo json_encode($urlCounts); ?>;
        const ctx1 = document.getElementById('urlBarChart').getContext('2d');
new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: Object.keys(urlCounts),
        datasets: [{
            label: 'Total URL Counts',
            data: Object.values(urlCounts),
            backgroundColor: '#3498DB',
            borderColor: '#2980B9',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            x: {
                ticks: { color: '#EAEAEA' },
                grid: { color: 'rgba(255, 255, 255, 0.2)' } // Light grid lines
            },
            y: {
                ticks: { color: '#EAEAEA', font: { size: 14 } },
                grid: { color: 'rgba(255, 255, 255, 0.2)' }
            }
        },
        plugins: {
            legend: {
                labels: { color: '#EAEAEA' }
            },
            tooltip: {
                titleColor: '#FFF',
                bodyColor: '#FFF',
                backgroundColor: '#333'
            }
        }
    }
});

<?php foreach ($groupedUrlCounts as $group => $data) { ?>
    const ctx_<?php echo $group; ?> = document.getElementById('chart_<?php echo $group; ?>').getContext('2d');
    new Chart(ctx_<?php echo $group; ?>, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode(array_keys($data)); ?>,
            datasets: [{
                label: '<?php echo $group; ?> - URL Counts',
                data: <?php echo json_encode(array_values($data)); ?>,
                backgroundColor: ['#9B59B6', '#3498DB', '#E74C3C', '#2ECC71'], // Brighter colors for contrast
                borderColor: '#FFFFFF', // White border for better separation
                borderWidth: 1
            }]
        },
        options: {
    responsive: true,
    maintainAspectRatio: false,
    animation: {
        duration: 1500,
        easing: 'easeOutQuart'
    },
    scales: {
        x: {
            ticks: { 
                color: '#EAEAEA', 
                font: { size: 14 } 
            },
            grid: { color: 'rgba(255, 255, 255, 0.2)' }
        },
        y: {
            ticks: {
                color: '#EAEAEA',
                font: { size: 14 },
                callback: function(value) { 
                    return Number.isInteger(value) ? value : ''; // Hide decimals
                }
            },
            grid: { color: 'rgba(255, 255, 255, 0.2)' }
        }
    },
    plugins: {
        legend: {
            labels: { color: '#EAEAEA', font: { size: 14 } }
        }
    }
}

    });
<?php } ?>

    </script>
</body>
</html>
