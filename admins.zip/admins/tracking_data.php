<?php
include 'db_connect.php';
$filterValue = isset($_GET['group_name']) ? $_GET['group_name'] : '';

// Fetch total count of entries
$totalQuery = "SELECT COUNT(*) as total FROM trace_data";
$totalResult = $conn->query($totalQuery);
$totalClicks = $totalResult->fetch_assoc()['total'];

// Fetch count grouped by group_name
$groupQuery = "SELECT group_name, COUNT(*) as count FROM trace_data GROUP BY group_name";
$groupResult = $conn->query($groupQuery);
$groupCounts = [];
while ($row = $groupResult->fetch_assoc()) {
    $groupCounts[$row['group_name']] = $row['count'];
}

// Fetch count grouped by url
$urlQuery = "SELECT url, COUNT(*) as count FROM trace_data GROUP BY url";
$urlResult = $conn->query($urlQuery);
$urlCounts = [];
while ($row = $urlResult->fetch_assoc()) {
    $urlCounts[$row['url']] = $row['count'];
}

// Fetch count of URLs within each group_name
$groupedUrlQuery = "SELECT group_name, url, COUNT(*) as count FROM trace_data GROUP BY group_name, url";
$groupedUrlResult = $conn->query($groupedUrlQuery);
$groupedUrlCounts = [];
while ($row = $groupedUrlResult->fetch_assoc()) {
    $groupedUrlCounts[$row['group_name']][$row['url']] = $row['count'];
}

// Fetch filtered data if group_name is set
$filteredData = [];
if ($filterValue) {
    $filterQuery = "SELECT url, contact, device, os, clicked_at FROM trace_data WHERE group_name = ?";
    $stmt = $conn->prepare($filterQuery);
    $stmt->bind_param("s", $filterValue);
    $stmt->execute();
    $filterResult = $stmt->get_result();
    while ($row = $filterResult->fetch_assoc()) {
        $filteredData[] = $row;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            background-color: #121212; 
            color: #fff; 
            padding: 20px; 
        }
        .container { 
            width: 90%; 
            margin: auto; 
        }
        .card {
            background: #1e1e1e;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
        }
        h2, h3 { text-align: center; }
        select, button {
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        select { background: #333; color: #fff; }
        button {
            background-color: #007BFF;
            color: white;
        }
        button:hover { background-color: #0056b3; }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #222;
            border-radius: 5px;
            overflow: hidden;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #444;
        }
        th { background-color: #007BFF; color: white; }
        tr:hover { background-color: #333; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h2>Total Clicks: <?php echo $totalClicks; ?></h2>
        </div>
        <div class="card">
            <h3>Filter by Group Name</h3>
            <form method="GET">
                <select name="group_name">
                    <option value="">Select Group</option>
                    <?php foreach ($groupCounts as $group => $count): ?>
                        <option value="<?php echo htmlspecialchars($group); ?>">
                            <?php echo htmlspecialchars($group); ?> (<?php echo $count; ?> clicks)
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit">Filter</button>
            </form>
        </div>
        
        <?php if ($filterValue): ?>
            <div class="card">
                <h3>Filtered Data for Group: <?php echo htmlspecialchars($filterValue); ?></h3>
                <table>
                    <tr>
                        <th>URL</th>
                        <th>Contact</th>
                        <th>Device</th>
                        <th>OS</th>
                        <th>Clicked At</th>
                    </tr>
                    <?php foreach ($filteredData as $row): ?>
                        <tr>
                            <td><?php echo $row['url']; ?></td>
                            <td><?php echo $row['contact']; ?></td>
                            <td><?php echo $row['device']; ?></td>
                            <td><?php echo $row['os']; ?></td>
                            <td><?php echo $row['clicked_at']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <h3>Click Data Analysis</h3>
            <canvas id="lineChart"></canvas>
        </div>
    </div>
    
    <script>
        const groupedUrlCounts = <?php echo json_encode($groupedUrlCounts); ?>;
        const groupNames = Object.keys(groupedUrlCounts);
        const urlLabels = <?php echo json_encode(array_keys($urlCounts)); ?>;
        const datasets = [];

        groupNames.forEach(group => {
            const counts = urlLabels.map(url => groupedUrlCounts[group][url] || 0);
            datasets.push({
                label: group,
                data: counts,
                borderColor: '#' + Math.floor(Math.random()*16777215).toString(16),
                backgroundColor: 'transparent',
                borderWidth: 2,
            });
        });

        new Chart(document.getElementById('lineChart').getContext('2d'), {
    type: 'line',
    data: { 
        labels: urlLabels, 
        datasets: datasets 
    },
    options: { 
        responsive: true,
        plugins: { 
            legend: { 
                position: 'top', 
                labels: { color: "#fff" } // Set legend text color
            },
            tooltip: { 
                bodyColor: "#fff", 
                titleColor: "#fff", 
                backgroundColor: "rgba(50,50,50,0.8)" // Dark tooltip with contrast
            }
        },
        scales: { 
            x: { 
                ticks: { color: "#fff" }, // Make x-axis labels visible
                grid: { color: "rgba(255,255,255,0.2)" } // Light gray gridlines
            },
            y: { 
                beginAtZero: true, 
                ticks: { color: "#fff" }, // Make y-axis labels visible
                grid: { color: "rgba(255,255,255,0.2)" } 
            } 
        } 
    }
});

    </script>
</body>
</html>
