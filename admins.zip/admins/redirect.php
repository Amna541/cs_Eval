<?php
session_start();
include 'db_connect.php'; // Ensure this connects to your database

function extractKeyword($url) {
    // Parse URL to get path
    $path = parse_url($url, PHP_URL_PATH);
    
    // Split the path into parts
    $parts = explode('/', trim($path, '/'));
    
    // Define a list of meaningful keywords (you can expand this list)
    $keywords = ['easypaisa', 'askari', 'csd', 'google', 'estate', 'facebook', 'warzone', 'hackathon', 'eshop', 'stylo'];

    // Check if any keyword exists in the URL path
    foreach ($keywords as $keyword) {
        foreach ($parts as $part) {
            if (stripos($part, $keyword) !== false) {
                return $keyword; // Return first matched keyword
            }
        }
    }

    // Default return if no keyword matches
    return 'unknown';
}

if (isset($_GET['url']) && isset($_GET['contact'])) {
    $originalUrl = urldecode($_GET['url']);
    $contact = base64_decode($_GET['contact']); // Decode contact info
    $group = base64_decode($_GET['group']);

    $keyword = extractKeyword($originalUrl);

    // Capture User Information
    function getUserIP() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } else {
            return $_SERVER['REMOTE_ADDR'];
        }
    }
    function getOS() {
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
    
        $os_platform = "Unknown OS";
    
        $os_array = [
            '/windows nt 10/i'    => 'Windows 10',
            '/windows nt 6.3/i'   => 'Windows 8.1',
            '/windows nt 6.2/i'   => 'Windows 8',
            '/windows nt 6.1/i'   => 'Windows 7',
            '/windows nt 6.0/i'   => 'Windows Vista',
            '/windows nt 5.1/i'   => 'Windows XP',
            '/macintosh|mac os x/i' => 'Mac OS X',
            '/mac_powerpc/i'      => 'Mac OS 9',
            '/linux/i'            => 'Linux',
            '/ubuntu/i'           => 'Ubuntu',
            '/iphone/i'           => 'iOS',
            '/ipod/i'             => 'iOS',
            '/ipad/i'             => 'iOS',
            '/android/i'          => 'Android',
            '/blackberry/i'       => 'BlackBerry',
            '/webos/i'            => 'Mobile'
        ];
    
        foreach ($os_array as $regex => $value) {
            if (preg_match($regex, $user_agent)) {
                $os_platform = $value;
                break;
            }
        }
    
        return $os_platform;
    }
    
    // Use this function
    
    
    $ip = getUserIP();
    
    $browser = $_SERVER['HTTP_USER_AGENT'];
    $os = getOS();
    
    $device = (strpos($browser, 'Mobile') !== false) ? 'Mobile' : 'Desktop';
    $timestamp = date("Y-m-d H:i:s");

    // Insert Click Data into Database
    $conn = new mysqli('localhost', 'root', '', 'trace_db'); // Update credentials
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO trace_data (contact, group_name, ip_address, browser, os,  device, clicked_at, url) VALUES (?,  ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $contact, $group, $ip, $browser, $os, $device, $timestamp, $keyword);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    echo $originalUrl;

    // Redirect user to the actual link
    header("Location: $originalUrl");
    exit();
} else {
    echo "Invalid request!";
}
?>
